package com.cdac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstOneApplication.class, args);
	}

}
