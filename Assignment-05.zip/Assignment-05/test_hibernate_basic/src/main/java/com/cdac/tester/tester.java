package com.cdac.tester;

import java.util.Scanner;

import org.hibernate.HibernateException;

import com.cdac.dao.TeamDao;
import com.cdac.dao.TeamDaoImpl;
import com.cdac.entities.Team;
import static com.cdac.utils.HibernateUtils.*;

public class tester {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            getSessionFactory();
            
            TeamDao teamDao = new TeamDaoImpl();

            System.out.println("Enter team details: name, abbreviation, owner, maxPlayerAge, battingAvg, wicketsTaken");
            Team team = new Team();
            team.setName(sc.next());
            team.setAbbreviation(sc.next());
            team.setOwner(sc.next());
            team.setMaxPlayerAge(sc.nextInt());
            team.setBattingAvg(sc.nextDouble());
            team.setWicketsTaken(sc.nextInt());

            System.out.println(teamDao.addTeam(team));
        } catch (HibernateException e) {
            e.printStackTrace();
        } finally {
        }
    }
}
