package com.cdac.dao;

import java.util.List;

import com.cdac.entities.Team;



public interface TeamDao {
    String addTeam(Team team);
	public List<Team> getAllTeams();
	public List<Team> getSelectedUsers(int maxplayerage, double batting_avg);
	public List<Team> getOwnernAbbreivatns(int maxplayerage, double batting_avg);
	public String changeAge(String Name, int age);
	List<Team> getAllDeatails();
}
