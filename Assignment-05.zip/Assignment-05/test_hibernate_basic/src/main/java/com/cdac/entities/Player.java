package com.cdac.entities;

import java.time.LocalDate;

import javax.persistence.*;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "Player")
@NoArgsConstructor
@Getter
@Setter
public class Player extends BaseEntity {
    @Column(length = 20, name = "first_name")
    private String firstName;

    @Column(length = 20, name = "last_name")
    private String lastName;

    private LocalDate dob;

    @Column(name = "batting_avg")
    private double battingAvg;

    @Column(name = "wickets_taken")
    private int wicketsTaken;

    @ManyToOne
    @JoinColumn(name = "team_id", nullable = false)
    private Team team;

    public Player(String firstName, String lastName, LocalDate dob, double battingAvg, int wicketsTaken, Team team) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.dob = dob;
        this.battingAvg = battingAvg;
        this.wicketsTaken = wicketsTaken;
        this.team = team;
    }
}
