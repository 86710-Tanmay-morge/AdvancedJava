package com.cdac.tester;


import org.hibernate.SessionFactory;

import com.cdac.dao.TeamDao;
import com.cdac.dao.TeamDaoImpl;
import static com.cdac.utils.HibernateUtils.getSessionFactory;

import java.util.Scanner;

public class OwnernAbreiv {

	public static void main(String[] args) {
		try (SessionFactory sf = getSessionFactory();
				Scanner sc=new Scanner(System.in)) {
			
			TeamDao tserDao=new TeamDaoImpl();
			System.out.println("Enter Max Age and Min batting to get OwnerName and Abreiv ");			
			tserDao.getSelectedUsers(sc.nextInt(),sc.nextDouble()).forEach(e->System.out.println(e.getAbbreviation()+" "+e.getOwner()));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}

