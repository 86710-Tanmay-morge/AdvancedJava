package com.cdac.tester;

import org.hibernate.SessionFactory;

import com.cdac.dao.TeamDao;
import com.cdac.dao.TeamDaoImpl;
import static com.cdac.utils.HibernateUtils.getSessionFactory;

import java.util.Scanner;

public class UpdateMaxAge {

	public static void main(String[] args) {
		try (SessionFactory sf = getSessionFactory(); Scanner sc = new Scanner(System.in)) {
			TeamDao userDao = new TeamDaoImpl();
			System.out.println("Enter Team Name And New AGE ");
			System.out.println(userDao.
					changeAge(sc.next(),sc.nextInt()));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
