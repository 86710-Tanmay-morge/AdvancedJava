package com.cdac.dao;

import org.hibernate.*;
import com.cdac.entities.Team;

import static com.cdac.utils.HibernateUtils.getSessionFactory;

import java.util.List;

public class TeamDaoImpl implements TeamDao {
    @Override
    public String addTeam(Team team) {
        String message = "Team registration failed!";
        Session session = getSessionFactory().getCurrentSession();
        Transaction tx = session.beginTransaction();
        try {
            session.save(team);
            tx.commit();
            message = "Team registered successfully!";
        } catch (RuntimeException e) {
            if (tx != null) {
                tx.rollback();
            }
            throw e; 
        }
        return message;
    }

	@Override
	public List<Team> getAllTeams() {
		String jpql = "select u from Team u";
		List<Team> users = null;
		// 1. get Session from SessionFactory
		Session session = getSessionFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			users = session.createQuery(jpql, Team.class).getResultList();
			// users - list of persistent entities.
			tx.commit();
		} catch (RuntimeException e) {
			// roll back the tx
			if (tx != null)
				tx.rollback();
			// re throw the same exception to the caller
			throw e;
		}

		return users;
	}

	@Override
	public List<Team> getSelectedUsers(int maxplayerage, double battingavg) {
		List<Team> teams = null;
		String jpql = "select u from Team u where u.maxPlayerAge>:age and u.battingAvg < :avg";
		Session session = getSessionFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		try {
			teams = session.createQuery(jpql, Team.class).setParameter("age", maxplayerage).setParameter("avg", battingavg)
					.getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}

		return teams;
	}

	@Override
	public List<Team> getOwnernAbbreivatns(int maxplayerage, double battingavg) {
		List<Team> teams = null;
		String jpql = "select new com.cdac.entities.Team(owner,abbreviation)  from Team u where u.maxPlayerAge>:age and u.battingAvg < :avg";
		Session session = getSessionFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		try {
			teams = session.createQuery(jpql, Team.class).setParameter("age", maxplayerage).setParameter("avg", battingavg)
					.getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}

		return teams;
	}

	@Override
	public String changeAge(String Name, int age) {
		Team team =null;
		String mesg = "Age Update Failure !!!!!!";
		String jpql = "select u from Team u where u.maxPlayerAge=:ages and u.name=:names";
		Session session = getSessionFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		try {
			team=session.createQuery(jpql, Team.class)
					.setParameter("names",Name)
					.setParameter("ages",age)
					.getSingleResult();
			
			team.setMaxPlayerAge(age);
			session.evict(team);
			tx.commit();
			mesg="Age changed Succesfully !";
				
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
				
		return mesg;
	}
	
	public List<Team> getAllDeatails(){
		String jpql = "select u from Team u";
		List<Team> users = null;
		Session session = getSessionFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		try {
			users = session.createQuery(jpql, Team.class).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}

		return users;
	}

	
	
}
