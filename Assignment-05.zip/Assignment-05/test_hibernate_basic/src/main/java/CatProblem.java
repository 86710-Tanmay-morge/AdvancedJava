import java.util.Scanner;
public class CatProblem {

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter Cats1 Cat2 Mouse Location:");
	int a = sc.nextInt();
	int b = sc.nextInt();
	int c = sc.nextInt();
    int d = Math.abs(a-c);
    int e = Math.abs(a-c);
    if(d==e) {
    	System.out.println("Mouce c");
    }
    if(d>e) {
    	System.out.println("cat1");
    }
    if(d<e) {
    	System.out.println("cat2");
    }
	}
}
