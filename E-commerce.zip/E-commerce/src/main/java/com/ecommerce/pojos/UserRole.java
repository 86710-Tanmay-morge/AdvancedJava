package com.ecommerce.pojos;

public enum UserRole {
	ADMIN,CUSTOMER
}
